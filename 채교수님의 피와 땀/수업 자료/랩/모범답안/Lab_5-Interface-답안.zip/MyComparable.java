public interface MyComparable {
	public int compareTo(final MyComparable other) ;
	public long getSize() ;
}
