
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class School {
	private final String name;
	private List<Student> students;
	private int capacity;
	
	public School(final String name, final int size) {
		this.name = name;
		students = new ArrayList<>(size);
		this.capacity = size;
	}
	public String getName() {
		return name;
	}
	public int getCapacity() { return capacity; }
	public int getSize() {
		return students.size();
	}
	public void add(Student newStudent) {
		students.add(newStudent);
	}
	@Override
	public String toString() {
		StringBuilder message = new StringBuilder("School Name: " + name + "\n");
		
		for ( Student student: students )
			message.append(student);
		
		return message.toString();
	}
	public void sortById() {
		Collections.sort(students, Student.IdComparator);
	}
	public void sortByGPA() {
		Collections.sort(students, Student.GpaComparator);
	}
	public void sortByName() {
		Collections.sort(students, Student.NameComparator);
	}
	public void sortByNameGPA() {
		Collections.sort(students, Student.NameGpaComparator);	
	}
}
