
import java.util.Comparator;

public class Student {
	private final int id;
	private String name;
	private double gpa;
	
	public Student(int id, String name, double gpa) {
		this.id = id;
		this.name = name;
		this.gpa = gpa;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGpa() {
		return gpa;
	}
	public void setGpa(float gpa) {
		this.gpa = gpa;
	}
	public int getId() {
		return id;
	}
	@Override
	public int hashCode() {
		return id;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return  id == other.id;
	}
	@Override
	public String toString() {
		return String.format("%d, %s, %5.2f%n", id,  name, gpa);
	}
	
	public static Comparator<Student> IdComparator = new Comparator<Student>() {
		@Override
        public int compare(Student s1, Student s2) {
            return s1.getId() - s2.getId();
        }
	};
	public static Comparator<Student> NameComparator = new Comparator<Student>() {
		@Override
        public int compare(Student s1, Student s2) {
            return s1.getName().compareTo(s2.getName());
        }
	};
	public static Comparator<Student> NameGpaComparator = new Comparator<Student>() {
		@Override
        public int compare(Student s1, Student s2) {
            final int nameCompare = s1.getName().compareTo(s2.getName());
            if ( nameCompare != 0 )
            	return nameCompare;
            else
            	return (int) ((s1.getGpa() - s2.getGpa()) * 100); 	
        }
	};
	public static Comparator<Student> GpaComparator = new Comparator<Student>() {
		@Override
        public int compare(Student s1, Student s2) {
            return (int) ((s1.getGpa() - s2.getGpa()) * 100);
        }
	};
}
