package Inheritance;

public abstract class Shape {
	public abstract float getArea();
}
